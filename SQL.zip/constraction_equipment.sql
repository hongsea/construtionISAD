CREATE TABLE tbCustractionEquipment (
id INT PRIMARY KEY IDENTITY (1,1),
name VARCHAR(45),
stock_qty INT,
unit_price DECIMAL
)