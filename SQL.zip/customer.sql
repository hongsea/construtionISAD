use dev_construction
CREATE TABLE tbCustomer (
id INT PRIMARY KEY IDENTITY(1,1),
name VARCHAR(45) NOT NULL,
gender VARCHAR(10) NOT NULL,
phone VARCHAR(15),
address VARCHAR(45),
);