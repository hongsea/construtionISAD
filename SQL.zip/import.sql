CREATE TABLE tbImport (
id INT PRIMARY KEY IDENTITY (1,1),
import_date DATE NOT NULL,
total_amount DECIMAL, 
staff_id INT NOT NULL,
FOREIGN KEY (staff_id) REFERENCES tbStaff(id),
supplier_id INT NOT NULL,
FOREIGN KEY (supplier_id) REFERENCES tbSupplier(id)
)