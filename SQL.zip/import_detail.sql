CREATE TABLE tbImportDetail (
id INT PRIMARY KEY IDENTITY (1,1),
import_qty INT NOT NULL, 
unit_price DECIMAL NOT NULL,
amount DECIMAL NOT NULL,
import_id INT NOT NULL,
FOREIGN KEY (import_id) REFERENCES tbImport (id),
CE_id INT NOT NULL,
FOREIGN KEY (CE_id) REFERENCES tbCustractionEquipment (id)
);