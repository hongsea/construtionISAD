CREATE TABLE tbInvoice (
id INT PRIMARY KEY IDENTITY (1,1),
total_amount DECIMAL NOT NULL,
paid_amount DECIMAL NOT NULL,
owes_amount DECIMAL NOT NULL,
invoice_date DATE NOT NULL,
staff_id INT NOT NULL,
FOREIGN KEY (staff_id) REFERENCES tbStaff(id),
customer_id INT NOT NULL,
FOREIGN KEY (customer_id) REFERENCES tbCustomer(id),
payment_id INT NOT NULL,
FOREIGN KEY (payment_id) REFERENCES tbPayment(id),
);