CREATE TABLE tbPayment (
id INT PRIMARY KEY IDENTITY (1,1),
payment_date DATE NOT NULL,
paid_amount DECIMAL NOT NULL,
customer_id INT NOT NULL,
FOREIGN KEY (customer_id) REFERENCES tbCustomer(id),
staff_id INT NOT NULL,
FOREIGN KEY (staff_id) REFERENCES tbStaff (id),
);