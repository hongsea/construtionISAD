CREATE TABLE tbProjectPlan (
id INT PRIMARY KEY IDENTITY (1,1),
projectplan_name VARCHAR (60) NOT NULL,
location VARCHAR (100) NOT NULL,
status VARCHAR (15) NOT NULL,
timeline DATE NOT NULL,
projectinformation_id INT NOT NULL,
FOREIGN KEY (projectinformation_id) REFERENCES tbProjectInformation(id)
);