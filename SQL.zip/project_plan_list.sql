CREATE TABLE tbProjectPlanList(
id INT PRIMARY KEY IDENTITY (1,1),
projectplanlist_name VARCHAR (60) NOT NULL,
status VARCHAR (15) NOT NULL,
start_date DATE NOT NULL,
finish_date DATE NOT NULL,
projectplan_id INT NOT NULL,
FOREIGN KEY (projectplan_id) REFERENCES tbProjectPlan(id),
staff_id INT NOT NULL,
FOREIGN KEY (staff_id) REFERENCES tbStaff(id)
);