CREATE TABLE tbProjectPlanListDetail (
id INT PRIMARY KEY IDENTITY (1,1),
projectplanlistDetail_name VARCHAR (60) NOT NULL,
dateline DATE NOT NULL,
projectplanlist_id INT NOT NULL,
FOREIGN KEY (projectplanlist_id) REFERENCES tbProjectPlanList(id)
);