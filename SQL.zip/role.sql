CREATE TABLE tbRole (
id INT PRIMARY KEY,
position varchar NOT NULL
);