CREATE TABLE tbStaff (
id int primary key IDENTITY (1,1),  
name varchar(30) not null,
gender varchar(7) not null, 
nationality varchar(20) not null,
birthday Date, hired_date Date ,
salary decimal ,
phone varchar(15) not null,
address varchar(45) not null,
photo varbinary(MAX),
role_id int not null references tbRole(id), status varchar(10)
)