CREATE TABLE tbUsage (
id INT PRIMARY KEY IDENTITY (1,1),
usage_date Date,
total_qty int,
staff_id INT NOT NULL,
FOREIGN KEY (staff_id) REFERENCES tbStaff (id),
CE_id INT NOT NULL,
FOREIGN KEY (CE_id) REFERENCES tbCustractionEquipment(id),
);