CREATE TABLE tbUsageDetail (
id INT PRIMARY KEY IDENTITY (1,1),
total_qty DECIMAL,
CE_id INT NOT NULL,
FOREIGN KEY (CE_id) REFERENCES tbCustractionEquipment(id),
);