CREATE TABLE tbUser (
id INT PRIMARY KEY IDENTITY (1,1),
username VARCHAR(45) NOT NULL,
password VARCHAR(45) NOT NULL,
staff_id INT NOT NULL,
FOREIGN KEY (staff_id) REFERENCES tbStaff(id),  
);