create table tbWorker (
id int identity primary key,
name varchar(30) not null,
gender varchar(7) not null,
birthday Date not null,
hired_date Date not null,
salary decimal not null ,
phone varchar(15) not null,
address varchar(45) not null,
photo varbinary(MAX),
role_id int not null references tbRole(id),
staff_id int not null references tbStaff(id), status varchar(10)
);